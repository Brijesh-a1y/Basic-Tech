
#define LED_PORT &PORTB
#define LED_PIN 5

#define BUTTON_PORT &PORTD
#define BUTTON_PIN 2

//or 

#define BUTTON_PIN PD2
#define LED_PIN PB5