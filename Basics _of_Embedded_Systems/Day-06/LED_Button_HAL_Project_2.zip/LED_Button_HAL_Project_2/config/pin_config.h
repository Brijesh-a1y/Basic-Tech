#ifndef PIN_CONFIG_H
#define PIN_CONFIG_H

#define LED_PIN PD4   //Digital pin 4 = PD4
#define BUTTON_PIN PD2

#endif